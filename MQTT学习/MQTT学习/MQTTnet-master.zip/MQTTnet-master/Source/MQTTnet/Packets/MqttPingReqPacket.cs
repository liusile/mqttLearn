﻿namespace MQTTnet.Packets
{
    public class MqttPingReqPacket : MqttBasePacket
    {
        public override string ToString()
        {
            return "PingReq";
        }
    }
}
