﻿namespace MQTTnet.Packets
{
    public class MqttPingRespPacket : MqttBasePacket
    {
        public override string ToString()
        {
            return "PingResp";
        }
    }
}
