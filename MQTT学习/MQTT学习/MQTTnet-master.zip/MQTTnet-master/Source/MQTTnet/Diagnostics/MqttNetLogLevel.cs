﻿namespace MQTTnet.Diagnostics
{
    public enum MqttNetLogLevel
    {
        Verbose,

        Info,

        Warning,

        Error
    }
}
