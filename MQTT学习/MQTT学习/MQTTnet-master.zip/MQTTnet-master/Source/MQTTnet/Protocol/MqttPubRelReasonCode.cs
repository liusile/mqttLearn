﻿namespace MQTTnet.Protocol
{
    public enum MqttPubRelReasonCode
    {
        Success = 0,
        PacketIdentifierNotFound = 146
    }
}
