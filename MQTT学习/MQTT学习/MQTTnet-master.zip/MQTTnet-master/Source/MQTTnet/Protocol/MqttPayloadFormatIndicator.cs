﻿namespace MQTTnet.Protocol
{
    public enum MqttPayloadFormatIndicator
    {
        Unspecified = 0,
        CharacterData = 1
    }
}
