﻿using System.Runtime.CompilerServices;

#if DEBUG
[assembly:InternalsVisibleTo("MQTTnet.Core.Tests")]
#endif
