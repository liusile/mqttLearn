﻿namespace MQTTnet.Client.Disconnecting
{
    public enum MqttClientDisconnectReason
    {
        NormalDisconnection = 0,

    }
}
