﻿namespace MQTTnet.Server
{
    public class MqttServerCertificateCredentials : IMqttServerCertificateCredentials
    {
        public string Password { get; set; }
    }
}
