public interface IMqttServerCertificateCredentials
{
    string Password { get; }
}
