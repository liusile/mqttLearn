﻿namespace MQTTnet.Extensions.Rpc.Options
{
    public class MqttRpcTopicPair
    {
        public string RequestTopic { get; set; }

        public string ResponseTopic { get; set; }
    }
}
