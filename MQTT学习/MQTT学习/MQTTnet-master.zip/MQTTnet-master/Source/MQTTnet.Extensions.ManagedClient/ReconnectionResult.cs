﻿namespace MQTTnet.Extensions.ManagedClient
{
    public enum ReconnectionResult
    {
        StillConnected,
        Reconnected,
        NotConnected
    }
}
