---
name: Custom issue template
about: Do you have a question related to the project? Use this template.
title: ''
labels: 'question'
assignees: ''

---

### Describe your question
A clear and concise description of what you want to know.

### Which project is your question related to?
<!-- Remove the items which don't apply from the following list -->
- Client
- ManagedClient
- MQTTnet.Server standalone
- Server
- Generic
